"""Independent bounded metadata/file-hash audit; does not replay raw source bodies."""
from __future__ import annotations
import hashlib
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
import stat
import subprocess
import sys
import time

if not __debug__:
    raise SystemExit("Independent review requires assertions enabled")

ROOT = Path("/workspace/scratch/9f3cdabec13b/ges")
WORK = ROOT / ".cache/cloud-replay-20261012/fresh-pinned"
OUTPUT = Path("/workspace/scratch/9f3cdabec13b/migration_review_fresh_cloud_replay.json")
HEAD = "6c37fe5eb98039341cb49444305703dc43048685"
started = datetime.now(timezone.utc).isoformat()
tick = time.monotonic()
checks = {}
bytes_hashed = 0
checked_paths = set()

def require(name, condition):
    checks[name] = bool(condition)
    if not condition:
        raise ValueError(name)

def regular(path):
    for component in (path, *path.parents):
        if component.is_symlink():
            raise ValueError("Symlink in observed path: " + str(component))
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError("Nonregular observed file: " + str(path))
    checked_paths.add(str(path))

def sha(path):
    global bytes_hashed
    regular(path)
    with path.open("rb") as stream:
        value = hashlib.file_digest(stream, "sha256").hexdigest()
    bytes_hashed += path.stat().st_size
    return value

def load(path):
    regular(path)
    return json.loads(path.read_text())

def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()

fields = ("source", "commit", "path", "kind", "sha256", "git_blob_sha", "size", "link_target")
def identity_digest(rows):
    return canonical([{field: row.get(field) for field in fields}
                      for row in sorted(rows, key=lambda row: row["path"])])

execution = load(WORK / "execution.json")
provenance_log = load(WORK / "claim-provenance.log")
accounting = load(WORK / "current-reconciliation-without-envelopes.log")
before = load(WORK / "input-closure-before.json")
after = load(WORK / "input-closure-after.json")
require("execution_is_pass_at_expected_head", execution["status"] == "PASS" and execution["head"] == HEAD)
require("actual_head_matches", subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip() == HEAD)
require("tracked_tree_still_clean", subprocess.run(
    ["git", "--no-optional-locks", "diff", "--quiet", "HEAD", "--"],
    cwd=ROOT, check=False).returncode == 0)
require("before_after_repository_closures_equal", before == after)
for relative, expected in after.items():
    p = Path(relative)
    require("safe_closure_path:" + relative, not p.is_absolute() and ".." not in p.parts)
    require("actual_closure_hash:" + relative, sha(ROOT / p) == expected)

a3_path = ROOT / "evidence/a3-six-source-capsule-repair.json"
origin_path = ROOT / "evidence/claim-workload-current-provenance.json"
inventory_report_path = ROOT / "evidence/claim-workload-v02-inventory.json"
require("a3_reference_hardcoded_digest", sha(a3_path) == "05dab95bfbc88c2401a97da702339f4f1be89545c8f8c9f48198194aac07bb15")
require("artifact_origin_hardcoded_digest", sha(origin_path) == "239fc3e89643202c9a7935749249eb4a0ca14e67a32c6e2a0517166a81e9bbf8")
require("current_membership_report_hardcoded_digest", sha(inventory_report_path) == "ed4ee7e8be9a5369d4651769dc8717456473063d2db21010544349a9848b8a00")
a3, origin, inventory_report = load(a3_path), load(origin_path), load(inventory_report_path)
lock_path = ROOT / "sources/sources.lock.json"
require("source_lock_a3_binding", sha(lock_path) == a3["capsule_manifest"]["source_lock_sha256"])
lock = load(lock_path)
specs = {s["repository"]: s for s in lock["sources"]}
require("unique_six_source_pins", len(specs) == len(lock["sources"]) == 6)
compressed = ROOT / "evidence/claim-workload-inputs/artifacts.jsonl.gz"
require("compressed_metadata_binding", sha(compressed) == origin["bindings"]["compressed_artifact_inventory_sha256"])
artifacts_path = WORK / "artifacts.oct7.jsonl"
require("decompressed_metadata_binding", sha(artifacts_path) == origin["bindings"]["artifact_inventory_sha256"])
require("decompressed_metadata_size", artifacts_path.stat().st_size == origin["metadata_projection"]["uncompressed_bytes"])
groups = defaultdict(list)
artifact_index = {}
with artifacts_path.open() as stream:
    for line in stream:
        if not line.strip():
            continue
        row = json.loads(line)
        identity = tuple(row[k] for k in ("source", "commit", "path"))
        if identity in artifact_index:
            raise ValueError("Duplicate source artifact identity")
        artifact_index[identity] = row
        groups[row["source"]].append(row)
require("complete_artifact_denominator", len(artifact_index) == 13657 == a3["capsule_manifest"]["accounting"]["inventory_artifacts"])
require("complete_repository_sets", set(groups) == set(specs) == set(a3["inventory_identity_digests"]))
source_records = {r["repository"]: r for r in execution["sources"]}
require("six_unique_recorded_source_executions", len(source_records) == len(execution["sources"]) == 6 and set(source_records) == set(specs))
require("source_hash_maps_equal", execution["source_input_hashes_before_replay"] == execution["source_input_hashes_after_replay"])
source_after = execution["source_input_hashes_after_replay"]
require("actual_source_member_set_equal", {"sources/" + p.name for p in (WORK / "sources").iterdir()} == set(source_after))
for relative, expected in source_after.items():
    p = Path(relative)
    require("safe_source_path:" + relative, not p.is_absolute() and ".." not in p.parts)
    require("actual_source_hash:" + relative, sha(WORK / p) == expected)
for repo, spec in specs.items():
    expected = a3["inventory_identity_digests"][repo]
    observed = source_records[repo]
    slug = repo.replace("/", "__")
    fresh = load(WORK / "sources" / (slug + ".inventory.json"))
    require("preserved_a3_identity:" + repo, identity_digest(groups[repo]) == expected)
    require("fresh_a3_identity:" + repo, identity_digest(fresh) == expected)
    require("artifact_counts:" + repo, len(groups[repo]) == len(fresh) == observed["artifacts"] == spec["artifacts"])
    require("text_counts:" + repo, sum(r["kind"] == "text" for r in fresh) == observed["text_artifacts"] == spec["text_artifacts"])
    require("binary_counts:" + repo, sum(r["kind"] == "binary" for r in fresh) == observed["binary_artifacts"] == spec["binary_artifacts"])
    require("archive_digest:" + repo, observed["archive_sha256"] == spec["archive_sha256"])
    require("commit_identity:" + repo, observed["commit"] == spec["commit"])
    tree = observed["git_tree_reconciliation"]
    require("fresh_tree_match:" + repo, tree["status"] == "MATCH" and tree["git_tree_artifacts"] == tree["archive_artifacts"] == spec["artifacts"] and not any(tree[k] for k in ("missing_from_archive", "extra_in_archive", "blob_mismatches")))
    require("snapshot_all_three_stages:" + repo, observed["snapshot_sha256"] == source_after["sources/" + slug + ".text.jsonl.gz"])
    require("inventory_all_three_stages:" + repo, observed["inventory_file_sha256"] == source_after["sources/" + slug + ".inventory.json"])
require("all_text_artifacts_count", sum(r["text_artifacts"] for r in source_records.values()) == execution["text_artifacts_authenticated"] == 11828)

expected_docs = {x["path"]: x for x in inventory_report["inputs"]["claim_documents"]}
actual_paths = sorted((ROOT / "evidence/source-reviews").glob("*-claims.json"))
require("exact_current_claim_filename_set", len(actual_paths) == len(expected_docs) == 655 and {p.name for p in actual_paths} == set(expected_docs))
observed_docs = {Path(x["path"]).name: x["sha256"] for x in provenance_log["review_documents"]}
require("provenance_consumed_exact_claim_documents", len(observed_docs) == len(provenance_log["review_documents"]) == 655 and observed_docs == {k: v["sha256"] for k, v in expected_docs.items()})
subjects = []
claim_ids = set()
needed_artifacts = set()
for path in actual_paths:
    raw = path.read_bytes()
    document_sha = hashlib.sha256(raw).hexdigest()
    require("expected_claim_document_hash:" + path.name, document_sha == expected_docs[path.name]["sha256"])
    document = json.loads(raw)
    require("expected_claim_document_count:" + path.name, len(document["claims"]) == expected_docs[path.name]["claims"])
    for claim in document["claims"]:
        claim_id = claim["claim_id"]
        if claim_id in claim_ids:
            raise ValueError("Duplicate claim identity")
        claim_ids.add(claim_id)
        source, commit, source_path = (claim.get(k, document.get(k)) for k in ("source", "commit", "path"))
        identity = (source, commit, source_path)
        original = artifact_index[identity]
        needed_artifacts.add(identity)
        subjects.append({
            "claim_id": claim_id, "source": source, "commit": commit, "path": source_path,
            "artifact_id": original["artifact_id"], "content_sha256": original["sha256"],
            "start_line": claim["start_line"], "end_line": claim["end_line"],
            "statement_sha256": hashlib.sha256(claim["statement"].encode()).hexdigest(),
            "claim_document": path.name, "claim_document_sha256": document_sha,
        })
subjects.sort(key=lambda r: r["claim_id"])
independent_claim_digest = canonical(subjects)
audit = load(ROOT / "evidence/v02-finish-20261010/claim-migration-audit.json")
independent_catalog_digest = canonical(load(ROOT / "controls/catalog.json"))
independent_proposal_digest = canonical(load(ROOT / "controls/review_queue.json"))
require("complete_unique_current_claim_universe", len(subjects) == len(claim_ids) == provenance_log["reference_claims"] == accounting["known_claim_denominator"] == 61941)
require("source_artifact_reference_count", len(needed_artifacts) == provenance_log["source_artifacts"] == 3556)
require("independent_claim_digest", independent_claim_digest == accounting["claim_input_digest"] == audit["current_claim_input_digest"])
require("independent_catalog_digest", independent_catalog_digest == accounting["catalog_digest"] == audit["catalog_digest"])
require("independent_proposal_digest", independent_proposal_digest == accounting["proposal_digest"] == audit["proposal_digest"])
require("actual_valid_cli_reports", provenance_log["valid"] is True and accounting["valid"] is True and accounting["claim_provenance_validated"] is True)
require("no_receipts_or_adoption_credit", accounting["validated_count"] == 0 and accounting["unresolved_count"] == 61941 and accounting["validated_claim_ids"] == [] and accounting["mapping_complete"] is False and accounting["rights_cleared"] is False and accounting["policy_adopted"] is False)
require("empty_receipt_policy_bindings", accounting["receipts_digest"] == canonical([]) and accounting["policy_digest"] == canonical({}))
for command in execution["commands"]:
    require("command_exit_and_log:" + command["name"], command["exit_code"] == 0 and sha(WORK / (command["name"] + ".log")) == command["log_sha256"])
driver_path = ROOT / ".cache/cloud-replay-20261012/fresh_source_replay.py"
require("reviewed_executed_v1_driver_hash", sha(driver_path) == "cefd1049a88ef4515efad1407c82c09d681368455292998b82eb4949cafeddd4")
result = {
    "schema": "ges.independent-fresh-cloud-replay-review.v1",
    "observer": "/root/migration_review",
    "observer_role": "Actual read-only independent code/metadata reviewer; not the original authorized reconciler or finishline_gates actor and not a human approver.",
    "started_at": started,
    "completed_at": datetime.now(timezone.utc).isoformat(),
    "elapsed_seconds": round(time.monotonic() - tick, 6),
    "status": "PASS_BOUNDED_INDEPENDENT_METADATA_AND_EXECUTION_REVIEW",
    "head": HEAD,
    "execution_started_at": execution["started_at"],
    "execution_completed_at": execution["completed_at"],
    "execution_scope": execution["scope"],
    "source_repositories": 6,
    "source_artifact_identities": len(artifact_index),
    "text_artifacts_authenticated_by_reviewed_execution": 11828,
    "claim_documents": len(actual_paths),
    "known_claims": len(subjects),
    "claim_referenced_source_artifacts": len(needed_artifacts),
    "independently_reconstructed_claim_input_digest": independent_claim_digest,
    "independently_reconstructed_catalog_digest": independent_catalog_digest,
    "independently_reconstructed_proposal_digest": independent_proposal_digest,
    "validated_current_receipts": 0,
    "unresolved_current_claims": accounting["unresolved_count"],
    "replacement_envelopes_issued": False,
    "historical_2164_field_interpretation": "Prior historical accounting reference only; neither carried decisions nor old receipt validity was revalidated by this driver or this review.",
    "original_cache_restored": False,
    "full_a3_capsule_authenticated": False,
    "rendered_cache_authenticated": False,
    "checks_passed": len(checks),
    "all_checks_passed": all(checks.values()),
    "files_checked_regular_without_symlinks_at_review": len(checked_paths),
    "raw_bytes_hashed_without_decompressing_source_bodies": bytes_hashed,
    "postrun_source_hashes_match_all_three_execution_stages": True,
    "postrun_repository_hashes_match_before_and_after_closures": True,
    "command": [sys.executable, str(Path(__file__).resolve())],
    "review_script_sha256": sha(Path(__file__).resolve()),
    "review_python_version": sys.version,
    "review_python_optimization": sys.flags.optimize,
    "evidence_sha256": {str(p.relative_to(ROOT)): sha(p) for p in (
        driver_path, WORK / "execution.json", WORK / "claim-provenance.log",
        WORK / "current-reconciliation-without-envelopes.log",
        WORK / "input-closure-before.json", WORK / "input-closure-after.json")},
    "limitations": [
        "The reviewer independently reconstructed source identity projections, every claim subject and all three input digests from metadata, and hashed the retained compressed source files; the reviewer did not duplicate the heavy source acquisition or decompress/revalidate all source bodies.",
        "Actual all-row content, Git-blob and line-span replay is supported by the reviewed v1 code and its execution/log records. Those verification functions use explicit exceptions, not removable assertions.",
        "V1 uses assertions for outer conditions and has no optimization guard. Historical v1 optimization mode was not independently observed; this review uses explicit checks and independently verifies the recorded metadata/hash conditions. A later guarded driver must not be misrepresented as the code executed by v1.",
        "V1 does not reject symlinks in its hash helper. This review observed only regular, non-symlink input/output paths after execution; it does not invent historical path-type observations.",
        "Source authentication and claim provenance do not certify semantic truth, source-to-claim omission completeness, rights, policy adoption, retained rendered-body fidelity or acceptance.",
        "No new receipt authority, reconciliation dispositions, human review, organization acceptance or release clearance is granted by this review."
    ]
}
with OUTPUT.open("x") as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({"status": result["status"], "checks_passed": len(checks), "output": str(OUTPUT), "output_sha256": sha(OUTPUT), "elapsed_seconds": result["elapsed_seconds"], "source_artifacts": len(artifact_index), "known_claims": len(subjects), "claim_input_digest": independent_claim_digest}, sort_keys=True))

